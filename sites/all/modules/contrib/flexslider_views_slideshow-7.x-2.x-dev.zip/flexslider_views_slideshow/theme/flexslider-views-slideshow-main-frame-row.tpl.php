<?php

/**
 * @file
 * Template for the FlexSlider row
 *
 * @author Mathew Winstone (minorOffense) <mwinstone@coldfrontlabs.ca>
 */
?>
  <li class="<?php print $classes; ?>">
    <?php print $rendered_items; ?>
  </li>
